package test_workshop_3;

import java.util.Random;
import java.util.Scanner;

public class test08 {

	public static void main(String[] args) {
		
		
		int [] score = {99,34,67,22,11,9};
		int min = 999;
		int max = -999;
		for (int i : score) {
			if (i>max) {
				max = i;
			}
			if(i<min) {
				min = i;
			}
		}
		
		System.out.println("최대값:"+max);
		System.out.println("최소값:"+min);
	}

}
