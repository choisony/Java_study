package test_workshop_3;

public class test02 {

	public static void main(String[] args) {
		
		int [] arr = {10,20,30,40,50};
		
		int sum =0;
		for (int i : arr) {
			sum +=i;
		}
		
		System.out.println("sum="+sum);
		System.out.println("avg="+sum/arr.length);
	}

}
