package test_workshop_3;

import java.util.Random;
import java.util.Scanner;

public class test07 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("키의 최댓값을 구합니다.");
		int num = scanner.nextInt();
		System.out.println("사람 수 :"+num);
		int max = -999;
		Random r = new Random();
		for (int i =1; i<num+1; i++) {
			int next_num = r.nextInt(50)+130;
			System.out.println("사람 "+i+": "+next_num);
			if (next_num >max) {
				max = next_num;
			}
		}
		System.out.println("최댓값은 "+max+"입니다.");
	}

}
