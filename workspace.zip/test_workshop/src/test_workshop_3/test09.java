package test_workshop_3;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class test09 {

	public static void main(String[] args) {
		
		Random r = new Random();
		int [] arr3 = new int[5];
		for (int i=0;i<arr3.length;i++) {
			arr3[i] = r.nextInt(10)+1;
		}
		System.out.println(Arrays.toString(arr3));
	}

}
