import java.util.Scanner;

public class Test08 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("1. 정수 입력하세요.");
		int first = scan.nextInt();
		System.out.println("2. 정수 입력하세요.");
		int second = scan.nextInt();
		int sum = first+second;
		System.out.println("정수 "+first+" 과 "+second+" 의 합계: "+ sum);
		
	}

}
