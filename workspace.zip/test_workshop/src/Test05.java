
public class Test05 {

	public static void main(String[] args) {
		byte a = 10;
		byte b = 20;
		byte c = 30;
		char ch = 'A';
		ch +=2;
		float f = 1.5f;
		long l = 27000000000l;
		float f2 = 0.1f;
		double d = 0.1;
		boolean result = (float)d != 0;
		System.out.println("c="+c);
		System.out.println("ch="+ch);
		System.out.println("f="+f);
		System.out.println("l="+l);
		System.out.println("result="+result);
		
		
		
	}

}
