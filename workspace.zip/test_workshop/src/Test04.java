
public class Test04 {

	public static void main(String[] args) {
		
		int fahrenheit = 100;
		float celcius = 5*((float)(fahrenheit)-32)/9;
		System.out.println("Fahrenheit:"+fahrenheit);
		System.out.println("Celcius:"+celcius);
	}

}
