import java.util.Scanner;

public class Test10 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("주소를 입력하시오.");
		String first = scan.next();
		String second = scan.next();
		String third = scan.next();
		System.out.println("도명: "+first);
		System.out.println("시명: "+second);
		System.out.println("구명: "+third);
		
	}

}
