package test04;

public class Company {
	private double salary;
	private double income;
	private double afterTaxIncome;
	private double bonus;
	private double afterTaxBonus;
	
	public Company() {}
	
	public Company(double salary) {
		this.salary = salary;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getIncome() {
		return 12 * salary;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	public double getAfterTaxIncome() {
		return this.getIncome() * 90/100;
	}

	public void setAfterTaxIncome(double afterTaxIncome) {
		this.afterTaxIncome = afterTaxIncome;
	}

	public double getBonus() {
		return  salary * 4 * 20/100;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public double getAfterTaxBonus() {
		return this.getBonus() * 94.5/100;
	}

	public void setAfterTaxBonus(double afterTaxBonus) {
		this.afterTaxBonus = afterTaxBonus;
	}

	@Override
	public String toString() {
		return "Company [salary=" + salary + ", income=" + income + ", afterTaxIncome=" + afterTaxIncome + ", bonus="
				+ bonus + ", afterTaxBonus=" + afterTaxBonus + "]";
	}
	
	
	
	
}
