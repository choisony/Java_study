package test04;

public class TestCompany {

	public static void main(String[] args) {
		Company c = new Company((double)(Integer.parseInt(args[0])));
		System.out.println("연 기본급 합: " + c.getIncome()+ " 세후: "+ c.getAfterTaxIncome());
		System.out.println("연 기본급 합: " + c.getBonus()+ " 세후: "+ c.getAfterTaxBonus());
		System.out.println("연 기본급 합: " + (c.getAfterTaxBonus()+ c.getAfterTaxIncome()));
	}
}
