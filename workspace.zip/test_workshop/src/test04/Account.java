package test04;

public class Account {
	String account;
	int balance;
	double interestRate;
	
	public Account() {}

	public Account(String account, int balance, double interestRate) {
		this.account = account;
		this.balance = balance;
		this.interestRate = interestRate;
	}
	
	public double calculateInterest() {
		return balance * interestRate / 100;
	}
	
	public void deposit(int money) {
		balance += money;
	}
	
	public void withdraw(int money) {
		if (balance - money <0){
			System.out.println("출금할 수 없습니다.");
		}else {
		balance -= money;
		}
	}

	@Override
	public String toString() {
		return "계좌정보: "+account+ " 현재잔액: "+ balance;
	}
	
	
}
