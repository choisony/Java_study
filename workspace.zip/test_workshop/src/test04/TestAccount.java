package test04;

public class TestAccount {

	public static void main(String[] args) {
		Account a1 = new Account("441-0290-1203",500000,7.3);
		
		System.out.println(a1);
		a1.withdraw(600000);
		a1.deposit(20000);
		System.out.println(a1);
		System.out.println("이자: "+ a1.calculateInterest());
	}

}
