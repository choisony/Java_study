package cafe;

public class CafeTest {

	public static void main(String[] args) {
		Cafe cafe = new Cafe();
		Coffee c1 = new Coffee("Americano",4000);
		Coffee c2 = new Coffee("Caffelatte",5000);
		Coffee c3 = new Coffee("Macchiato",6000);
		
		cafe.setCoffee(c1);
		cafe.setCoffee(c2);
		cafe.setCoffee(c3);
		
		for (int i=0; i<cafe.coffeeList.length;i++) {
			System.out.println(cafe.coffeeList[i]);
		}
		System.out.println();
		System.out.println("Coffee 가격의 합: "+ cafe.totalPrice()+"원");
	}

}
