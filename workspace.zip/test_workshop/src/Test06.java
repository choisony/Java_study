
public class Test06 {

	public static void main(String[] args) {
		int i = 5;
		String result = (i%2!=0)?"홀수":"짝수";
		System.out.println("선언 변수 "+ i +" 일때 결과:");
		System.out.println("숫자 "+i+" 는 "+result+"입니다");
	}

}
