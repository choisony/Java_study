package calc;

public class TestCalc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calc c = new Calc();
		int input = Integer.parseInt(args[0]);
		if (input<5 && input>10) {
			System.out.println("다시 입력하세요.");
		}else {
			System.out.println("결과: " +c.calculate(input));
		}
		
		
	}

}
