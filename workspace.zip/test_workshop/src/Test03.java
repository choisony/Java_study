
public class Test03 {

	public static void main(String[] args) {
		
		char ch = 'z';
		
		boolean b = Character.isAlphabetic(ch);
		System.out.println(b);
	}

}
