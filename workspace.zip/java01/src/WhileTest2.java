import java.util.Scanner;

public class WhileTest2 {	
	public static void main(String[] args) {


		while(true) {
			Scanner scan = new Scanner(System.in);
			System.out.println("이름을 입력하세요: , Q입력시 종료");
			String name = scan.next();
			if (name.equals("q")) break;
			System.out.println("이름은 "+name);
		}
	}
}