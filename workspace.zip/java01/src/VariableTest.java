public class VariableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1. 변수 선언
		int age;
		String name;
		float height;
		boolean isMarried;
		
		// 2. 변수 초기화
		age = 26;
		name = "최성민";
		height = 176.5F;
		isMarried = false;
		
		System.out.println(age);
		System.out.println(name);
		System.out.println(height);
		System.out.println(isMarried);
		

	}
}