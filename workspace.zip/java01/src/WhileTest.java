public class WhileTest {	
	public static void main(String[] args) {
		// 반복문
		/*
		 * 구성요소
		 * - 시작값
		 * - 조건식
		 * - 증감식
		 * 
		 */
		//while 문
		int n=1;
		while(n<=5) {
			System.out.println("hello "+n);
			n++;
		}


		for(int i=5;i>0;i--) {
			System.out.println("Hello " + i);
		}
		
		for (int i=2; i<10; i++) {
			for (int j=1; j<10;j++) {
				System.out.println(i+"*"+j+"="+i*j);
			}
		}
		
	}
}