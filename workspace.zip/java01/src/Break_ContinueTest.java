import java.util.Scanner;

public class Break_ContinueTest {	
	public static void main(String[] args) {
		
		//break : 가장 가까운 반복문을 빠져 나올 때 사용
		for(int i=5;i>0;i--) {
			System.out.println("Hello " + i);
			if (i==4) break;
		}
		
		//continue : 반복처리되는 문장들 중에서 임의의 문장을 skip 할 때
		for(int i=5;i>0;i--) {
			System.out.println("Hello " + i);
			if (i==3) continue;
			System.out.println("Bye " + i);
		}
		
	}
}