import java.util.Scanner;

public class DoWhileTest {	
	public static void main(String[] args) {


		int num = 10;
		
		while(num<8) { // while문은 조건식이 먼저 나오기 때문에 한번도 실행안될 수 있다.
			System.out.println("while 문");
			num++;
		}
		
		int num2 = 10;
		do { // do~while 문은 조건식이 나중에 나오기 때문에 적어도 한번은 실행될 수 있다.
			System.out.println("do~while문");
			num2++;
		}while(num2 < 8);
	}
}