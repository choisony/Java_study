public class VariableTest3 {
	// method 밖
	// main method
	int num = 100; // 인스턴스 변수, heap 메모리
	static int sum= 200; // static 변수, method area 메모리
	
	public static void main(String[] args) {
		// method 안 -> 로컬변수, stack 메모리에 저장됨.
		int age = 10;
		float height;
		height = 220;
		System.out.println(age);
		System.out.println(height);
		
		VariableTest3 s = new VariableTest3();
		// 인스턴스 변수는 반드시 객체생성하고 사용한다.
		System.out.println(s.num);
		System.out.println(sum);
	}
}