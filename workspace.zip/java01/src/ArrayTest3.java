public class ArrayTest3 {	
	public static void main(String[] args) {
		
		int [] n;
		n = new int[] {100,200,300,400}; // 이 방법에서 크기 지정하면 Error
		// 크기는 중괄호에 의해 결정됨.
		
		System.out.println(n[2]);
	}
}