public class ArrayTest {	
	public static void main(String[] args) {
		
		// 배열 사용
		// 1. 배열 선언 (데이터타입 [] 배열명;)
		int [] n; //n ==> 변수, 참조형변수, 배열명, 로컬변수(stack)
		
		// 2. 배열 생성 (배열명 = new 데이터타입[size]
		n = new int[5]; // new를 이용한 객체생성이기 때문에 heap메모리에 생성됨.
		
		// 배열길이 => 배열명.length
		// 문자열길이 => 문자열.length()
		// 컬렉션 크기 =>size()
//		System.out.println(n[0]);
//		System.out.println(n[1]);
//		System.out.println(n[2]);
		
		// 3. 배열 초기화
		n[0] = 100;
		n[1] = 200;
		n[2] = 300;
//		n[6] = 1; 	// 없는 위치 접근 시 
					// java.lang.ArrayIndexOutOfBoundsException 오류 발생
		for (int idx = 0; idx < n.length; idx++) {
			System.out.println(n[idx]);
		}
		
	}
}