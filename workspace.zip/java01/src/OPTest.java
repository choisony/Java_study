public class OPTest {	
	public static void main(String[] args) {
		
		
		// 1. 산술연산자
		int n = 10;
		int n2 = 3;
		System.out.println(n + n2);
		System.out.println(n - n2);
		System.out.println(n * n2);
		System.out.println(n / n2);
		System.out.println(n % n2);

		// 2. 비교연산자 (논리값 true/false 로 반환)
		System.out.println(n > n2);
		System.out.println(n >= n2);
		System.out.println(n < n2);
		System.out.println(n <= n2);
		System.out.println(n == n2); // 같냐? 기본형: == 연산자 이용, 참조형: equals() 이용
		System.out.println(n != n2);
		
		// 3. 대입연산자 ==> 값을 대입(그냥 대입, 더해서 대입, 빼서 대입, 곱해서 대입, 나눠서 대입..)
		int x = 10;
		int x2 = 20;
		x +=x2;
		System.out.println(x);
		
		// 4. 증감연산자 ==> 값을 1 증가(증가 연산자), 값을 1 감소(감소 연산자)
		// 독자적으로 사용시 전치 및 후치 결과는 동일하다. 그런데 다른 연산자 사용시 값이 달라질 수 있다.
		int k=10;
		k++;
		++k;
		System.out.println(k);
		k--;
		System.out.println(k);
		
		int z1 = 10;
		int z2= 10;
		int result = ++z1; // 전치는 먼저 증가하고 나중에 result에 할당.
		int result2 = z2++; // 후치는 먼저 result에 할당하고 나중에 증가
		System.out.println(z1 + " " + result);
		System.out.println(z2 + " " + result2);
		
		
	}
}