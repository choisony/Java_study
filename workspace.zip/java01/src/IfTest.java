public class IfTest {	
	public static void main(String[] args) {
		//1. 조건문
		// 가. 단일 if문 : 조건에 따라서 실행여부 결정
		
		System.out.println("1");
		if (false) {
			System.out.println("2");
			System.out.println("3");
		}
		System.out.println("end");

		// 나. if~else 문: 조건에 따라서 실행되는 문장이 다를때 사용

		System.out.println("1");
		if (true) {
			System.out.println("20");
		}
		else {
			System.out.println("33");
		}
		
		// 다. 다중 if문:
		int num =8;
		if (num>=90) {
			System.out.println("A");
		}else if (num >=80) {
			System.out.println("B");
		}else if (num >=70) {
			System.out.println("C");
		}else {
			System.out.println("D");
		}
		
		
		// switch문 break 가 필수는 아님. 일반적으로 쓰긴함.
		int key = 9999;
		switch(key){
		case 5:
			System.out.println("5");
			break;
		case 10:
			System.out.println("10");
			break;
		case 15:
			System.out.println("15");
			break;
		default:
			System.out.println("모두 만족하지 않을 때 실행");
			break;
		}
		
		// switch에 지정 가능한 타입 : byte, short, int, long(x), char
		
		char key2 = 'a';
		switch(key2){
		case 'a':
			System.out.println("a");
			break;
		default:
			System.out.println("모두 만족하지 않을 때 실행");
			break;
		}
		
		String key3 = "AAA";
		switch(key3){
		case "AAA":
			System.out.println("AAA");
			break;
		default:
			System.out.println("모두 만족하지 않을 때 실행");
			break;
		}
	}
}