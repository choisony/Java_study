public class ArrayTest2 {	
	public static void main(String[] args) {
		
		int [] n = {100,200,300}; //선언과 초기화 한번에 해야됨.
		
		
		for (int i = 0; i < n.length; i++) {
			System.out.println(n[i]);
		}
		
		int [] n2;
		n = new int[] {100,200,300}; // 이 방법에서 크기 지정하면 Error
	}
}