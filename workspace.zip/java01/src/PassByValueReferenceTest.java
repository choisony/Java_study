import java.util.Arrays;

public class PassByValueReferenceTest {	
	
	public static void pdt(int n) {
		n = 20;
	}
	
	public static void rdt(int [] x) {
		x[2] = 500;
		x[0] = 10000;
	}
	
	
	public static void main(String[] args) {
		// 기본형
		int num = 10;
		System.out.println("변경 전 값: " + num);
		pdt(num); // call by value : 기본형 데이터 전달, 실제값이 전달됨.
		// 따라서 메서드에서 값 변경해도 원본값 변경 안됨.
		System.out.println("변경 후 값: " + num);
		
		// 참조형
		int [] n = {100,200,300};
		System.out.println("변경 전 값: " + Arrays.toString(n));
		rdt(n); // call by value reference : 참조형 데이터 전달, 실제값(주소값),
		// 메서드에서 값 변경하면 원본값도 변경 됨.
		System.out.println("변경 후 값: " + Arrays.toString(n));
	}
}