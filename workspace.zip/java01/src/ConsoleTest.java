public class ConsoleTest {	
	public static void main(String[] args) {
		
		
		/* 콘솔에 출력
		 * println ==> new line 생성
		 * print ==> new line 생성 안됨
		 * printf ==> 포맷 지정시 사용 printf("포맷",값, 값1, ....)
		 * 
		 * 
		 */
		System.out.println("Hello");
		System.out.println("Hello2");
		System.out.println("Hello3");
		System.out.println();
		
		System.out.print("Hello");
		System.out.print("Hello2");
		System.out.print("Hello3");
		System.out.println();
		System.out.println();
		
		System.out.printf("이름:%s 나이:%d 키:%f 성별:%c 결혼여부%b","홍길동",20, 183.14125123, '남', true);
	
	}
}