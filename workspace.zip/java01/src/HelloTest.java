
public class HelloTest {

	public static void main(String[] args) {
		// 주석문
		System.out.println("Hello World!!");
		System.out.println(20);
		System.out.println(3.14F);
		System.out.println(3.14D);
		System.out.println('A');
		System.out.println("홍길동"); //기본형X, 참조형임 (문자열)
		System.out.println(true);
		System.out.println(false);
		System.out.println("adad");
	}

}
