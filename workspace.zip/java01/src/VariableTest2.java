public class VariableTest2 {

	public static void main(String[] args) {
		{
			int age = 10;
			System.out.println(age);
		}
		// System.out.println(age); 
		int age = 20;
		System.out.println(age);

		int x;
		if(true) {
			x = 15;
		}
		System.out.println(x);
		
	}
}