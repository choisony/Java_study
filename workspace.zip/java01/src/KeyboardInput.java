import java.util.Scanner;

public class KeyboardInput {	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("이름을 입력하세요 : ");
		String name = scan.nextLine();
		System.out.println("나이를 입력하세요 : ");
		int age = scan.nextInt();
		
		System.out.println(name+" "+age);
		System.out.println("end");
	}
}