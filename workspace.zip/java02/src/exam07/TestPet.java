package exam07;

public class TestPet {

	public static void main(String[] args) {

		Cat c = new Cat("망치",2,"암컷");
		System.out.println(c.getPet());
	}

}