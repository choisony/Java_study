package exam07;

public class Pet{ // extends Object는 자동삽입
	String name;
	int age;
	
	public Pet() {
		super();
	}
	
	public Pet(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}



	public void eat() {}
	
	// Pet 정보 반환 메서드
	public String getPet() {
		return name+"\t"+age;
	}
}
