package exam04;

public class TestPet {

	public static void main(String[] args) {
		
		Cat c = new Cat();
		Cat c1 = new Cat("뭉크",1,"암컷");
		
		c1.setAge(12);
		c1.setName("망치");
		c1.setSex("수컷");
		
		
//		System.out.println(c1.name);
//		System.out.println(c1.age);
//		System.out.println(c1.sex);
	
		c1.setNameAge("야옹이", 20);
//		System.out.println(c1.name);
//		System.out.println(c1.age);
//		System.out.println(c1.sex);
		
		c1.setNameAgeSex("냥", 230, "Male");
//		System.out.println(c1.name);
//		System.out.println(c1.age);
//		System.out.println(c1.sex);
		// cat 인스턴스 변수 값 얻기: 메서드를 권장
		// 위에 처럼 직접 접근은 권장 안함.
		
		String name = c1.getName();
		int age = c1.getAge();
		String sex = c1.getSex();
		
		System.out.println(name);
		System.out.println(age);
		System.out.println(sex);
	
		Dog d = new Dog("멍멍",2);
		System.out.println(d.toString());
	}

}

