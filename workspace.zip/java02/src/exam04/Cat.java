package exam04;

public class Cat {

	private String name; //처음에 null로 초기화
	private int age; // 처음에 0으로 초기화
	private String sex; //처음에 null로 초기화
				// boolean은 처음에 false로 초기화	

	public Cat() {
	}
	public Cat(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}
	
	// age 변경하는 메서드
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setNameAge(String name, int age) {
		this.name = name;
		this.age = age;	
	}
	
	public void setNameAgeSex(String name, int age, String sex) {
		this.name = name;
		this.age = age;	
		this.sex = sex;
	}
	
	public String getName() {
		return this.name;
	}
	public int getAge() {
		return this.age;
	}
	public String getSex() {
		return this.sex;
	}
	@Override
	public String toString() {
		return "name=" + name + ", age=" + age + ", sex=" + sex;
	}
	
	

	

	
}