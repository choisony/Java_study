package exam02;

public class TestPet {

	public static void main(String[] args) {
		
		Cat c = new Cat();
		
		// 호출 시 argument list 가 반드시 일치해야한다.
		// 1) 개수
		// 2) 타입
		// 3) 순서
		
		// 호출하는 Caller값을 argument라고 부른다.
		Cat c1 = new Cat("야옹이");
		Cat c2 = new Cat("망치",4);
		Cat c3 = new Cat("뭉크",1,"암컷");
	}

}

