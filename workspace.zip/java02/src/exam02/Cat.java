package exam02;

// 분석 단계의 고양이 객체
public class Cat {
	
	// 인스턴스 변수(멤버 변수)
	String name; //처음에 null로 초기화
	int age; // 처음에 0으로 초기화
	String sex; //처음에 null로 초기화
				// boolean은 처음에 false로 초기화	
	
	// 생성자	(기본생성자는 public 클래스명(){})
	// 오버로딩 생성자
	// 정의 : 하나의 클래스 내에 동일한 이름의 생성자가 여러개 지정ㄱ능.
	//		단, argument list가 반드시 달라야한다.
	public Cat() {
		System.out.println("cat 생성자");
	}
	
	// {}을 가진 worker 쪽의 변수를 파라미터(parameter)라고 함.
	public Cat(String name) { // this.name의 위치 heap, name의 위치 stack
		this.name = name;
		System.out.println("cat1 생성자");
	}
	
	public Cat(String name, int age) {
		this.name = name;
		this.age = age;
		System.out.println("cat2 생성자");
	}
	
	public Cat(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
		System.out.println("cat3 생성자");
	}

	// 메서드(멤버 메서드, 인스턴스 메서드)
		
	

	
}