package exam06;

public class Pet{ // extends Object는 자동삽입
	
	// 공통적인 속성
	String name;
	int age;
	
	public Pet() {
		// super();
		System.out.println("Pet 생성자");
	}
	// 공통적인 기능
	public void eat() {}
	
}
