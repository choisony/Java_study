package exam05;

public class Test {

	static int num;
	int size;
	
	public void a() {
		System.out.println(num);
		System.out.println(size);
		System.out.println(this);
	}
	public static void b() {
		System.out.println(num);
//		System.out.println(size); // 접근 불가
//		System.out.println(this);
		// this 사용 불가, 인스턴스 생성이 아직 안된 상태
		// static 이 먼저 생성됨.
	}
	
}
