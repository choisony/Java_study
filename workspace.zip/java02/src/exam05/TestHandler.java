package exam05;

public class TestHandler {

	public static void main(String[] args) {
		
		// 인스턴스(new) 전에 접근 가능
		Test.b();
		Test.num = 20;
		
		// 인스턴스 접근은 반드시 객체생성이후에
		Test t = new Test();
		
		t.a();
		t.size = 10;
	}

}
