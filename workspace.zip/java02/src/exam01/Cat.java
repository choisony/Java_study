package exam01;

// 분석 단계의 고양이 객체
public class Cat {
	
	// 인스턴스 변수(멤버 변수)
	String name; //처음에 null로 초기화
	int age; // 처음에 0으로 초기화
	String sex; //처음에 null로 초기화
				// boolean은 처음에 false로 초기화	
	
	// 생성자	(기본생성자는 public 클래스명(){})
	public Cat(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}

	// 메서드(멤버 메서드, 인스턴스 메서드)
		
	

	
}