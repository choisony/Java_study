package exam01;

public class TestPet {

	public static void main(String[] args) {
		
		// 객체생성
		// 클래스명 변수명 = new 클래스명();
		// c ==> 로컬변수, 참조형변수
		Cat c = new Cat("야옹이",2,"암컷");
		
		// 초기화 작업
//		c.name = "야옹이";
//		c.age = 2;
//		c.sex = "암컷";
		
		System.out.println(c.name);
		System.out.println(c.age);
		System.out.println(c.sex);
		System.out.println();
		
		Cat c2 = new Cat("망치",4,"수컷");
//		c2.name = "망치";
//		c2.age = 4;
//		c2.sex = "수컷";
		 
		System.out.println(c2.name);
		System.out.println(c2.age);
		System.out.println(c2.sex);
	}

}
