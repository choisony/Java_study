package exam03;

public class Cat {

	String name; //처음에 null로 초기화
	int age; // 처음에 0으로 초기화
	String sex; //처음에 null로 초기화
				// boolean은 처음에 false로 초기화	
	public Cat() {
		// TODO Auto-generated constructor stub
	}
	public Cat(String name) {
		this.name = name;
	}
	public Cat(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public Cat(String name, int age, String sex) {
		this.name = name;
		this.age = age;
		this.sex = sex;
	}

	

	
}