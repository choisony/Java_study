package exam03;

public class TestPet {

	public static void main(String[] args) {
		
		Cat c = new Cat();
		Cat c1 = new Cat("야옹이");
		Cat c2 = new Cat("망치",4);
		Cat c3 = new Cat("뭉크",1,"암컷");
	}

}

