package com.pet3;

public interface Flyer {
//	int num = 10; // public static final 자동지정
	public abstract void fly(); // public abstract 자동지정되지만 명시적으로 준거
	
	
}
