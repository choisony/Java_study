package com.pet3;

public class TestPet {

	public static void main(String[] args) {
		
//		Flyer f = new Flyer(); //인터페이스는 new 생성 불가
		
//		Flyer f = new Dog();
//		Flyer f = new Cat(); //얘들은 Flyer implements 안해서 안됨.
		
		// 다형성 적용 (직접 생성은 안되지만 다형성을 이용하여 타입으로는 쓸 수 있다.)
		Flyer f = new Bird();
			  f = new Bug();
		
	}

}
