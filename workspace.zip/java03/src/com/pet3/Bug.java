package com.pet3;

public class Bug extends Pet implements Flyer{

	String height;
	
	//
	@Override
	public void fly() {}
	
	
	@Override
	public void eat() {}
	
}
