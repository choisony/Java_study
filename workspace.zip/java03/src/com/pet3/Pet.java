package com.pet3;

public abstract class Pet{
	String name;
	int age;
	
	// 공통적인 기능
	// 강제성을 부여하기 위해 추상메서드 정의
	// 누구는 쓰고 누구는 안쓸수 있기때문에
	public abstract void eat();
	
	
	
	public Pet() {
		
	}
	public Pet(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Pet [name=" + name + ", age=" + age + "]";
	}
	
	
	
}
