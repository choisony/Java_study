package com.pet3;

public class Bird extends Pet implements Flyer{

	String weight;
	
	//
	
	
	@Override
	public void fly() {}
	
	@Override
	public void eat() {}
	
}
