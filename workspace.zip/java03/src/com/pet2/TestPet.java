package com.pet2;

public class TestPet {

	public static void main(String[] args) {
		
		//다형성 적용
//		Pet p = new Pet() // pet은 추상클래스이기 때문에 생성 안됨.
		Pet p = new Cat("야옹이",1,"암컷");
		p.eat();
			p = new Dog("망치",2,"블랙");
		p.eat();
		
	}

}
