package com.lambda;

@FunctionalInterface
public interface Flyer3 {
	// 파라미터 있고 리턴값 있음.
	public abstract int fly(int x, int x2);
}
