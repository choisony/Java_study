package com.lambda;

@FunctionalInterface
public interface Flyer2 {
	// 파라미터 있고 리턴값 없음.
	public abstract void fly(int x, String x2);
}
