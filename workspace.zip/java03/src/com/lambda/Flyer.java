package com.lambda;

@FunctionalInterface
public interface Flyer {
	// 파라미터 없고 리턴값 없음.
	public abstract void fly();
//	public abstract void fly2(); annotation 때문에 2개 이상의 추상메서드 불가능	
	
	

}
