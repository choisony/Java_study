package com.pet;

public class TestPet4 {

	// 다형성 적용 시 메소드 오버로드 필요없이 메소드 하나로 해결 가능
//	public static void method(Cat c) {}
//	public static void method(Dog d) {}
	public static void method(Pet p) {}
//	public static void method(Object o) {}
	
	
	public static void main(String[] args) {
		
		// 다형성 적용 예
		// 1. 배열 (안에 pet 타입이면 됨)
		Cat c = new Cat();
		Dog d = new Dog();
		Pet p = new Pet();
		
		method(c);
		method(d);
		method(p);
	}
}
