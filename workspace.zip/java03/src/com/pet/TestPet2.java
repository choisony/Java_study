package com.pet;

public class TestPet2 {

	public static void main(String[] args) {
		
		// 다형성 적용 예
		// 1. 배열 (안에 pet 타입이면 됨)
		Cat c = new Cat("야옹이",1,"암컷");
		Pet[] p = {c, 
				new Cat("망치",2,"수컷"), 
				new Dog("멍멍이",3,"흰둥이"),
				new Dog("멍멍3",4,"블랙"),
				new Dog("멍멍4",5,"갈색")};
		
	}
}
