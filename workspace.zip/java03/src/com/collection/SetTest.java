package com.collection;

import java.util.HashSet;
import java.util.Set;

public class SetTest {

	public static void main(String[] args) {
		
		// 순서없고 중복 불가
		// 인터페이스여서 new 할 시 Error
//		Set s = new Set();
		Set s = new HashSet();
		s.add("홍길동");
		s.add(2);
		s.add("홍길동");
		s.add(true);
		// 출력방법 1
		System.out.println(s); //s.toString() 호출
		
		// 출력방법 2
		for (Object obj : s) {
			System.out.println(obj);
		}
		
		System.out.println();
		// Generics 이용: 저장되는 데이터 타입 제한
		Set<String> s2 = new HashSet<String>();
		s2.add("홍길동");
//		s2.add(2); //Error
		s2.add("홍길동");
		s2.add("최성민");
		System.out.println(s2); //s.toString() 호출
		for (Object obj : s2) {
			System.out.println(obj);
		}
		
		System.out.println();
		Set<Integer> s3 = new HashSet<Integer>();
		s3.add(2);
		s3.add(4);
		s3.add(1);
		s3.add(7);
		System.out.println(s3); //s.toString() 호출
		for (Object obj : s3) {
			System.out.println(obj);
		}
	}

}
