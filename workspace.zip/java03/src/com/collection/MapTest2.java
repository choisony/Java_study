package com.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapTest2 {

	public static void main(String[] args) {
		
		// 고양이 2마리 관리: 야옹이 2 암컷, 망치 1 수컷
		// Map 저장후에 모든 고양이 출력하시오.
		Map<Integer, Cat> list = new HashMap<>();
		list.put(1, new Cat("야옹이",2,"암컷"));
		list.put(2, new Cat("망치",1,"수컷"));
		
		Set<Integer> keys = list.keySet();
		for (Integer key : keys) {
			System.out.println(key + " -> " + list.get(key));
		}
		
	}

}
