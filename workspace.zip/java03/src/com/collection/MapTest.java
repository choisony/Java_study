package com.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapTest {

	public static void main(String[] args) {
		
		// key/value 쌍으로 저장
		Map<String, String> m = new HashMap<>();
		
		//데이터 저장
		m.put("p1","tv");
		m.put("p2","phone");
		m.put("p3","notebook");
		m.put("p3","pc"); // key가 동일하면 마지막에 저장한 데이터로 덮음.
		
		
		
		// 값 출력 : 반드시 key 이용하여 value값을 반환받음
		// 1) key 알고있을 때
		System.out.println(m.get("p1"));
		System.out.println(m.get("p2"));
		System.out.println(m.get("p3"));
		System.out.println(m.get("p5")); // 없는 key 사용 시 null 반환
		System.out.println();
		
		// 2) key 값만 따로 얻고 나중에 value 얻는다.
		Set<String> keys = m.keySet();
		System.out.println(keys);
		for (String key : keys) {
			System.out.println(key + " -> "+m.get(key));
		}
		
		// 값 삭제
		System.out.println();
		m.remove("p1");
		System.out.println(m);
		
	}

}
