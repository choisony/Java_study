package com.collection;

import java.util.ArrayList;
import java.util.List;

public class ListTest {

	public static void main(String[] args) {

	
		// 순서있고 중복가능
		List<String> list1 = new ArrayList<>();
		List<String> list2 = new ArrayList<String>();
		
		list1.add("홍길동1");
		list1.add("홍길동2");
		list1.add("홍길동3");
		list1.add("홍길동1");
		
		//삽입
		list1.add(0, "이순신"); // 0번째 위치에 이순신 삽입
		
		//수정
		list1.set(1,"유관순"); // 1번째 위치에 값을 유관순으로 변경
		
		//삭제
		list1.remove(0); // 0번째 위치에 있는 이순신 값 삭제
		list1.remove("홍길동1");
	
		/*
		 * remove(int index) : 위치값으로 삭제
		 * remove(object obj) : 값으로 삭제
		 * 
		 * 
		 */
//		list1.remove(1); // 1 위치값이 삭제됨
//		list1.remove(new Integer(1)); // 값으로 삭제하려면 obj 형식으로 만들어줘야함.
//		System.out.println(list1);
		
		//값 출력1
		System.out.println(list1);
		
		//값 출력2 - 첨자(index) 사용 가능
//		System.out.println(list1.get(2));
//		System.out.println(list1.get(1));
		System.out.println();
		for (String s : list1) {
			System.out.println(s);
		}
	
	}
}
