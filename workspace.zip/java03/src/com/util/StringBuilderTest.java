package com.util;

public class StringBuilderTest {

	public static void main(String[] args) {
		
		// StringBuilder
		StringBuilder s = new StringBuilder("sequence");
		System.out.println(s); // s.toString()
		
		String x = s.toString();
		System.out.println(x);
		
		// 가공
		// 가장많이 사용되는 함수는 append 이다.
		s.append(" AAA ");
		s.append(" BBB ");
		s.append(" CCC ");
		System.out.println(s); // 원본이 변경된다.(고무줄)
		
		s.insert(0, "HELLO ");
		System.out.println(s);
		s.insert(s.length()-1, " BYE");
		System.out.println(s);
		
		s.delete(0, 6); // 0~5 까지 삭제
		System.out.println(s);
		
		System.out.println(s.reverse());
		
		
		
	}

}