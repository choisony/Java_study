package com.util;

import java.util.StringTokenizer;

public class StringTokenizerTest {

	public static void main(String[] args) {
		String mesg = "홍길동/이순신/유관순";
		StringTokenizer st = new StringTokenizer(mesg, "/");
		
		// nextToken 전에 확인 먼저 할 수 있음. (hasMoreToken() ->return type boolean)
		while(st.hasMoreTokens()) {
			String s = st.nextToken();
			System.out.println(s);	
		}		
	}

}