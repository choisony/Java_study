package com.ktds;

public class Customer {
	
}
