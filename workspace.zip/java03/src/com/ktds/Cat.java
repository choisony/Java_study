package com.ktds;

public class Cat {

}
