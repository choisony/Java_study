package com.anony;

public interface Flyer {
	public abstract void fly();
	
}
