import com.ktds.Customer;
import pet.Cat;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cat c = new Cat();
		Customer cust = new Customer();
	}

}
