package pet;

public class Cat {

}
